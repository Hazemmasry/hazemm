#def main():
 #   x= 0
  #  while (x<=50):
   #     print(x)
    #    x = x+1
#main()
#or i in range (5,10):
   #print (i)
#r(i=0;i<50;i++)
 #  print(i)
for i in range(1,10):
    if(i//2==2): continue
    print(i)