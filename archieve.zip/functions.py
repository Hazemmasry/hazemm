def power (num,x=1):
    result=1
    for i in range (x):
        result=result*num
    return result
print(power(22,3))