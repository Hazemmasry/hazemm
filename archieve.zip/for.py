for i,x in enumerate( ["sat","sun","mon", "tu",'wed','thu','fri']):

        print(i+1,x+" is the day")