def main():


    print("hello world")
    name = input("enter your name: ")
    print("welcome dear user " + name )


if __name__ == "__main__":
    main()
