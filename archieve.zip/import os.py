import uui
from uui import path
import datetime
from datetime import date,time,timedelta
import time
def main():
    print(uui.name)
if __name__ == '__main__':
