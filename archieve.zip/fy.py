def main(x, z):
    y = x + z
    return y


x = input("en  x")
z = input("en  z")

m = main(x, z)
print(m)
