import os
from os import path
import datetime
from datetime import date,time,timedelta
import time
def main():
    print(os.name)
    print("path exist: "+str(path.exists("hazem.pdf")))
main()
