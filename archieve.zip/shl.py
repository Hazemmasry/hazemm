import os
from os import path
import shutil
from shutil import make_archive

def main():
    if path.exists("file.txt"):
        scr = path.realpath("file.txte")
        des = scr + ".bak"
        # shutil.copy(scr,des)
        # shutil.copystat(scr,des)
        # os.rename("file.txt", "hazemmm.txt")
        root_dir, tail=path.split(scr)
        shutil.make_archive("archieve","zip",root_dir)
if __name__ == '__main__':
    main()
