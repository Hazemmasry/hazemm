from datetimie import date
from datetimie import time
from datetimie import datetime
def main ():
    today=date.today()
    print("today is  ",today)
if __name__ == '__main__':
