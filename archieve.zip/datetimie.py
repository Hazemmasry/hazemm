from datetime import  datetime
from datetime import timedelta

def main():
    now=datetime.now()
    print(now.strftime("the current year is % y"))

if __name__ == '__main__':
