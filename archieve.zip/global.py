f=12
def str():
    global f
    f=2
    print(f)
str()
print(f)